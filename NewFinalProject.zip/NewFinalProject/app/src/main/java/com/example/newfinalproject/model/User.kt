package com.example.newfinalproject.model

class User (var username: String = "", var age: Int = 0)
